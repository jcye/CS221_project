import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;

public class project {
	
	static int k = 200;
	static HashMap<Integer, HashSet<Integer>> matrix = new HashMap<Integer, HashSet<Integer>>();
	static HashMap<Integer, HashMap<Integer,Double>> simMatrix = new HashMap<Integer, HashMap<Integer,Double>>();
	static int numTrainUser=53412;
	static int numTestUser=10000;
	//static int numTrainUser=10000;
	//static int numTestUser=10000;
	static double bar = 0.46;
	static int toPredict = 137;
	public static void main(String[] args){
		//readDataV2("traindata.txt","testdatasimple.txt");
		readDataV2("apps1CF.tsv",true);
		readWord("SVMinput_words.txt");
		System.out.println("finish reading data");
		getSimMatrix();
		System.out.println("finish calculating sim matrix");
		for(double i = 0.15; i < 0.16; i += 0.05)
		{
			bar = i;
			System.out.print(i+" ");
			double score[]=predict();
			System.out.println("finish predicting");
			evaluate(score);
		}

		System.out.println("done");
	}
	public static void evaluate(double[] score){
		double tp = 0;
		double fp=0;
		double fn=0;
		for (int i=numTrainUser;i<numTrainUser+numTestUser;i++){
			if(matrix.get(i).contains(toPredict)&&score[i-numTrainUser]>=bar){
				tp++;
				System.out.print(i+" ");
			}
			if(matrix.get(i).contains(toPredict)&&score[i-numTrainUser]<bar){
				fn++;
			}
			if(!matrix.get(i).contains(toPredict)&&score[i-numTrainUser]>=bar){
				fp++;
			}
		}
		if(tp+fp>0){
			System.out.println("precision: "+(tp/(tp+fp)));		
		} else {
			System.out.println("precision: 0");	
		}
		if(tp+fn>0){
			System.out.println("recall:"+(tp/(tp+fn)));
		} else {
			System.out.println("recall: 0");
		}
		
	}
	public static double[] predict(){
		double score[]=new double[numTestUser];
		for (int i=numTrainUser;i<numTrainUser+numTestUser;i++){
			double up = 0;
			double down = 0;
			Iterator<Integer> itr = simMatrix.get(i).keySet().iterator();
			while(itr.hasNext()) {
				int neighborId=itr.next();
				if (matrix.get(neighborId).contains(toPredict)){
					up+=simMatrix.get(i).get(neighborId);
				}
				down += simMatrix.get(i).get(neighborId);
			}
			if(down!=0){
				score[i-numTrainUser] = up/down;
			}
		}
		return score;
	}
	public static void getSimMatrix(){
		for (int i =numTrainUser; i < numTrainUser+numTestUser;i++){
			if((i-numTrainUser)%100==0){
				System.out.println("got the sim matrix for "+ (i-numTrainUser));
			}
			
			PriorityQueue<SimScore> queue = new PriorityQueue<SimScore>();
			for (int j = 0; j < numTrainUser;j++){
				if(i==j){
					continue;
				}
				double iNum=matrix.get(i).size();
				double jNum=matrix.get(j).size();
				double ijNum=0;
				
				Iterator<Integer> itr = matrix.get(i).iterator();
				while(itr.hasNext()){
					int job = itr.next();
					if(job==toPredict){
						continue;
					}
					if(matrix.get(j).contains(job)) {
						ijNum++;
					}
				}
				
				if(matrix.get(i).contains(toPredict)){
					iNum--;
				}
				if(matrix.get(j).contains(toPredict)){
					jNum--;
				}
				double rate;
				if(iNum==0||jNum==0){
					rate = 0;
				} else {
					rate = ijNum/Math.sqrt(iNum)/Math.sqrt(jNum);
				}
				SimScore simScore = new SimScore(j,rate);
				queue.add(simScore);
				if (queue.size()>k){
					queue.remove();
				}
			}
			Iterator<SimScore> itr = queue.iterator();
			while(itr.hasNext()){
				SimScore simScore = itr.next();
				simMatrix.get(i).put(simScore.id, simScore.score);
			}
		}
	}
	
	public static void readWord(String trainPath) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(trainPath));
			String strLine;
			for(int i=0;i<numTrainUser+numTestUser;i++) {
				strLine = in.readLine();
				String dataLine[]=strLine.split(" ");
				for(int j =1;j<dataLine.length;j++) {
					matrix.get(i).add((100000+Integer.parseInt(dataLine[j])));
				}
			}
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	public static void readDataV2(String trainPath, boolean withWord) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(trainPath));
			String strLine;
			strLine = in.readLine();
			strLine = in.readLine();
			strLine = in.readLine();
			for (int i = 0; i < numTrainUser+numTestUser; i ++) {
				matrix.put(i, new HashSet<Integer>());
			}
			for (int i = numTrainUser; i < numTrainUser+numTestUser; i ++) {
				simMatrix.put(i, new HashMap<Integer,Double>());
			}
			
			for(int i=0;i<numTrainUser+numTestUser;i++) {
				strLine = in.readLine();
				String dataLine[]=strLine.split(" ");
				for(int j =0;j<dataLine.length;j++) {
					int num=Integer.parseInt(dataLine[j]);
					if(withWord){
						matrix.get(i).add(num);
					} else {
						if(num==toPredict){
							matrix.get(i).add(num);
						}
					}
				}
			}
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
}

class SimScore implements Comparable<SimScore>{
	int id;
	double score;
	public SimScore(int id, double score){
		this.id=id;
		this.score=score;
	}
	public int compareTo( SimScore other ){
		if(this.score-other.score>0) {
			return 1;
		}
		if(this.score-other.score==0){
			return 0;
		}
		return -1;
	}
	public String toString(){
		return id+":"+score;
	}
}