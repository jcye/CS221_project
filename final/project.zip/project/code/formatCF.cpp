//
//  main.cpp
//  formatCF
//
//  Created by Jinchao Ye on 11/20/12.
//  Copyright (c) 2012 Jinchao Ye. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <iterator>
using namespace std;
#define LINE_SIZE 1000

void saveWindowFile(ofstream & fout, ifstream & fin, int splitWindowID){
    char line_char[LINE_SIZE];
    string line;
    fin.getline(line_char, LINE_SIZE);
    line = line_char;
    fout << line_char << "\n";
    while (!fin.eof()) {
        int userID = -1;
        int windowID = -1;
        string split = "-1";
        string applicatioDate1 = "-1";
        string applicatioDate2 = "-1";
        int jobID = -1;
        fin>>userID>>windowID>>split>>applicatioDate1>>applicatioDate2>>jobID;
        if(windowID == splitWindowID)
            fout<<userID<<"\t"<<windowID<<"\t"<<split<<"\t"<<applicatioDate1<<" "<<applicatioDate2<<"\t"<<jobID<<"\n";
        else
            break;
    }
}

void processTable(map<int, int> & userIDMap, map<int, int> & jobIDMap, vector<vector<int> *> & appTable, map<int, int> & jobCount, int & numJobs, int & numUsers){
    ifstream fin;
    fin.open("/Users/jcye/Dropbox/CS221Project/Data/apps1.tsv");
    char line_char[LINE_SIZE];
    string line;
    fin.getline(line_char, LINE_SIZE);
    line = line_char;
    cout << line_char << "\n";
    int userIndex = -1;
    int jobIndex = -1;
    while (!fin.eof()) {
        int userID = -1;
        int windowID = -1;
        string split = "-1";
        string applicatioDate1 = "-1";
        string applicatioDate2 = "-1";
        int jobID = -1;
        fin>>userID>>windowID>>split>>applicatioDate1>>applicatioDate2>>jobID;
        if(userID == -1){
            break;
        }
        if(!userIDMap.count(userID)){
            userIndex++;
            userIDMap[userID] = userIndex;
            appTable.push_back(new vector<int>());
        }
        if(!jobIDMap.count(jobID)){
            jobIndex++;
            jobIDMap[jobID] = jobIndex;
        }
        appTable[userIndex]->push_back(jobIDMap[jobID]);
        if(!jobCount.count(jobID)){
            jobCount[jobID] = 0;
        }
        jobCount[jobID]++;
    }
    numJobs = jobIndex + 1;
    numUsers = userIndex + 1;
    fin.close();
}

int getMostAppliedJobID(map<int, int> & jobCount){
    int maxID = -1;
    int maxCount = -1;
    for(auto it=jobCount.begin(); it != jobCount.end(); it++){
        if(it->second > maxCount){
            maxCount = it->second;
            maxID = it->first;
        }
    }
    cout<<"maxID = "<<maxID<<" maxCount "<<maxCount<<"\n";
    return maxID;
}

void outputTable(vector<vector<int> *> & appTable, int maxID, int numJobs){
    ofstream fout;
    fout.open("/Users/jcye/Dropbox/CS221Project/Data/apps1CF.tsv");
//    for(int i = 0; i < appTable.size(); i++){
//        cout<<i<<" out of "<<appTable.size()-1 <<"\n";
//        int k = 0;
//        bool flag = false;
//        for(int j = 0; j < appTable[i]->size(); j++){
//            //cout<<j<<" out of "<<appTable[i]->size()-1<<"\n";
//            if(j > 0){
//                k = (*appTable[i])[j-1] + 1;
//            }
//            while(k < (*appTable[i])[j]){
//                if(k==maxID){
//                    k++;
//                    continue;
//                }
//                fout<<0<<" ";
//                k++;
//            }
//            if((*appTable[i])[j]==maxID){
//                flag = true;
//                continue;
//            }
//            fout<<1<<" ";
//        }
//        k = (*appTable[i])[appTable[i]->size()-1];
//        while(k < numJobs){
//            if(k==maxID){
//                k++;
//                continue;
//            }
//            fout<<0<<" ";
//            k++;
//        }
//        if(flag)
//            fout<<1<<" ";
//        else
//            fout<<0<<" ";
//        fout<<"\n";
//    }
    fout<<appTable.size()<<"\n";
    fout<<numJobs<<"\n";
    fout<<maxID<<"\n";
    for(int i = 0; i < appTable.size(); i++){
        cout<<i<<" out of "<<appTable.size()-1 <<"\n";
        for(int j = 0; j < appTable[i]->size(); j++){
            fout<<(*appTable[i])[j]<<" ";
        }
        fout<<"\n";
    }
    fout.close();
    return;
}

void outputUserMap(map<int,int> & userIDMap){
    ofstream fout;
    fout.open("/Users/jcye/Dropbox/CS221Project/Data/apps1CFUserMap.tsv");
    for(map<int,int>::iterator it = userIDMap.begin(); it != userIDMap.end(); it++){
        cout<<it->first<<" "<<it->second<<"\n";
        fout<<it->first<<" "<<it->second<<"\n";
    }
    fout.close();
    return;
}

void outputJobMap(map<int, int> & jobIDMap){
    ofstream fout;
    fout.open("/Users/jcye/Dropbox/CS221Project/Data/apps1CFJobMap.tsv");
    for(auto it = jobIDMap.begin(); it != jobIDMap.end(); it++){
        fout<<it->first<<" "<<it->second<<"\n";
    }
    fout.close();
    return;
}

bool judgePositive(vector<int> * appTableRow, int maxID){
    for(int i = 0; i < appTableRow->size(); i++){
        if((*appTableRow)[i]==maxID){
            return true;
        }
    }
    return false;
}

void outputTableSVMFormat(vector<vector<int> *> & appTable, int maxID, int numJobs, int numUsers){
    ofstream fout;
    fout.open("/Users/jcye/Dropbox/CS221Project/Data/apps1SVM.tsv");
    ofstream foutTrain;
    foutTrain.open("/Users/jcye/Dropbox/CS221Project/Data/apps1SVMTrain.tsv");
    ofstream foutTest;
    foutTest.open("/Users/jcye/Dropbox/CS221Project/Data/apps1SVMTest.tsv");
    int numTest = 10000;
    fout<<numUsers<<" "<<numJobs<<"\n";
    foutTrain<<numUsers - numTest<<" "<<numJobs<<"\n";
    foutTest<<numTest<<" "<<numJobs<<"\n";
    //fout<<maxID<<"\n";
    int count = 1;
    for(int i = 0; i < appTable.size(); i++){
        cout<<i<<" out of "<<appTable.size()-1 <<"\n";
        if(judgePositive(appTable[i], maxID)){
            fout<<1<<" ";
            for(int j = 0; j < appTable[i]->size(); j++){
                if ((*appTable[i])[j]!=maxID) {
                    fout<<(*appTable[i])[j]<<" ";
                }
            }
            if(count <= numUsers - numTest){
                foutTrain<<1<<" ";
                for(int j = 0; j < appTable[i]->size(); j++){
                    if ((*appTable[i])[j]!=maxID) {
                        foutTrain<<(*appTable[i])[j]<<" ";
                    }
                }
            }
            else{
                foutTest<<1<<" ";
                for(int j = 0; j < appTable[i]->size(); j++){
                    if ((*appTable[i])[j]!=maxID) {
                        foutTest<<(*appTable[i])[j]<<" ";
                    }
                }
            }
        }
        else{
            fout<<0<<" ";
            for(int j = 0; j < appTable[i]->size(); j++){
                fout<<(*appTable[i])[j]<<" ";
            }
            if(count <= numUsers - numTest){
                foutTrain<<0<<" ";
                for(int j = 0; j < appTable[i]->size(); j++){
                    foutTrain<<(*appTable[i])[j]<<" ";
                }
            }
            else{
                foutTest<<0<<" ";
                for(int j = 0; j < appTable[i]->size(); j++){
                    foutTest<<(*appTable[i])[j]<<" ";
                }
            }
        }
        fout<<"\n";
        if (count <= numUsers - numTest) {
            foutTrain<<"\n";
        }
        else{
            foutTest<<"\n";
        }
        count++;
    }
    foutTrain.close();
    foutTest.close();
    fout.close();
    return;
}


int main(int argc, const char * argv[])
{
//    ifstream fin;
//    fin.open("/Users/jcye/Dropbox/CS221Project/Data/apps.tsv");
//    ofstream fout;
//    fout.open("/Users/jcye/Dropbox/CS221Project/Data/apps1.tsv");
//    if(fin){
//        cout<<"successfully reading the file\n";
//        saveWindowFile(fout, fin, 1);
//    }
//    else{
//        cout<<"unable to open file\n";
//    }
//    fin.close();
//    fout.close();
    map<int, int> userIDMap;
    map<int, int> jobIDMap;
    vector<vector<int> *> appTable;
    map<int, int> jobCount;
    int numJobs = -1;
    int numUsers = -1;
    processTable(userIDMap, jobIDMap, appTable, jobCount, numJobs, numUsers);
    cout<<numJobs<<"\n";
    //outputUserMap(userIDMap);
    //outputJobMap(jobIDMap);
    int maxJobCountID = getMostAppliedJobID(jobCount);
    cout << maxJobCountID << "\n";
    cout << jobIDMap[maxJobCountID] << "\n";
    //outputTable(appTable, jobIDMap[maxJobCountID], numJobs);
    outputTableSVMFormat(appTable, jobIDMap[maxJobCountID], numJobs,numUsers);
    return 0;
}

