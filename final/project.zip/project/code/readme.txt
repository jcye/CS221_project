Yun Lou (yunlou)
Jinchao Ye (jcye)

This project is "recommending jobs to users".

formatCF.cpp: the code to convert apps1.tsv to convenient format for collaborative filtering. It also take care of jobID matching and userID matching.
Project.java : the code for collaborative filtering
PrepareData.java : the code to convert the data to sparse matrix format so that we can use lib-linear (matlab version) directly.
lr_train.m: matlab file for logistic regression training.
lr_test.m: matlab file for logistic regressin predicting and curve plotting.
readMatrix.m: read the sparse matrix for svm & logistic regression.
svm_train.m: matlab file for svm training.
svm_test.m : matlab file for svm testing.