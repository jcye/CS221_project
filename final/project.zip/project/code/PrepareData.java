import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;

public class PrepareData {
	static HashMap<String, Integer> dict = new HashMap<String, Integer>();
	static HashMap<Integer, HashSet<Integer>> usersWords = new HashMap<Integer, HashSet<Integer>>();
	static HashMap<Integer, Integer> userId = new HashMap<Integer, Integer>();// their
																				// user
																				// id
																				// to
																				// our
																				// user
																				// id
	static int k = 200;
	static HashMap<Integer, HashSet<Integer>> matrix = new HashMap<Integer, HashSet<Integer>>();
	static HashMap<Integer, HashMap<Integer,Double>> simMatrix = new HashMap<Integer, HashMap<Integer,Double>>();
	static int numTrainUser=53412;
	static int numTestUser=10000;
	//static int numTrainUser=4000;
	//static int numTestUser=3000;
	static int numJobs;
	static int toPredict = 137;

	public static void main(String[] args) {
		readUserIdMapping("apps1CFUserMap.tsv");
		System.out.println();
		readData("user_history.tsv");
		System.out.println("finish reading user history");

		readDataV2("apps1CF.tsv");
		System.out.println("finish reading data");
		boolean dataWithCF=false;
		if(dataWithCF){
			getSimMatrix();
			System.out.println("finish calculating sim matrix");
			double score[] = predict();
			System.out.println("finish predicting");
			
			buildSVMinputCFWords(score, project.toPredict);
		} else{
			//buildSVMinputJobsWords("SVMinput_jobs_words.txt");
			//buildSVMinputWords("SVMinput_words.txt");
			buildSVMinputJobs("SVMinput_jobs.txt");
		}
		System.out.println("done");
	}
	public static void buildSVMinputWords(String output){
		try {
			// Create file
			FileWriter fstream = new FileWriter(output);
			BufferedWriter out = new BufferedWriter(fstream);
			for (int i = 0; i < matrix.size(); i++) {//users.size()
				HashSet<Integer> jobSet = matrix.get(i);
				if(jobSet.contains(toPredict)){
					out.write("1 ");
				} else {
					out.write("0 ");
				}
				jobSet.remove(toPredict);

				HashSet<Integer> words = usersWords.get(i);
				Iterator<Integer> itr = words.iterator();
				while(itr.hasNext()){
					int word = itr.next();
					out.write(word+" ");
				}
				out.newLine();
			}
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	public static void buildSVMinputJobs(String output){
		try {
			// Create file
			FileWriter fstream = new FileWriter(output);
			BufferedWriter out = new BufferedWriter(fstream);
			for (int i = 0; i < matrix.size(); i++) {//users.size()
				HashSet<Integer> jobSet = matrix.get(i);
				if(jobSet.contains(toPredict)){
					out.write("1 ");
				} else {
					out.write("0 ");
				}
				
				Iterator<Integer> itr = jobSet.iterator();
				while(itr.hasNext()){
					int word = itr.next();
					if(word!=toPredict){
						out.write(word+" ");
					}
				}
				
				out.newLine();
			}
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	public static void buildSVMinputJobsWords(String output){
		try {
			// Create file
			FileWriter fstream = new FileWriter(output);
			BufferedWriter out = new BufferedWriter(fstream);
			for (int i = 0; i < matrix.size(); i++) {//users.size()
				HashSet<Integer> jobSet = matrix.get(i);
				if(jobSet.contains(toPredict)){
					out.write("1 ");
				} else {
					out.write("0 ");
				}
				jobSet.remove(toPredict);
				
				Iterator<Integer> itr = jobSet.iterator();
				while(itr.hasNext()){
					int word = itr.next();
					out.write(word+" ");
				}

				HashSet<Integer> words = usersWords.get(i);
				itr = words.iterator();
				while(itr.hasNext()){
					int word = itr.next()+100000;
					out.write(word+" ");
				}
				out.newLine();
			}
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	public static double[] predict(){
		double score[]=new double[numTrainUser+numTestUser];
		for (int i=0;i<numTrainUser+numTestUser;i++){
			double up = 0;
			double down = 0;
			Iterator<Integer> itr = simMatrix.get(i).keySet().iterator();
			while(itr.hasNext()) {
				int neighborId=itr.next();
				if (matrix.get(neighborId).contains(toPredict)){
					up+=simMatrix.get(i).get(neighborId);
				}
				down += simMatrix.get(i).get(neighborId);
			}
			if(down!=0){
				score[i] = up/down;
			}
		}
		return score;
	}
	public static void getSimMatrix(){
		for (int i = 0; i < numTrainUser+numTestUser;i++){
			if(i%100==0){
				System.out.println("got the sim matrix for "+ (i));
			}
			
			PriorityQueue<SimScore> queue = new PriorityQueue<SimScore>();
			for (int j = 0; j < numTrainUser;j++){
				if(i==j){
					continue;
				}
				double iNum=matrix.get(i).size();
				double jNum=matrix.get(j).size();
				double ijNum=0;
				
				Iterator<Integer> itr = matrix.get(i).iterator();
				while(itr.hasNext()){
					int job = itr.next();
					if(job==toPredict){
						continue;
					}
					if(matrix.get(j).contains(job)) {
						ijNum++;
					}
				}
				
				if(matrix.get(i).contains(toPredict)){
					iNum--;
				}
				if(matrix.get(j).contains(toPredict)){
					jNum--;
				}
				double rate = ijNum/Math.sqrt(iNum)/Math.sqrt(jNum);
				SimScore simScore = new SimScore(j,rate);
				queue.add(simScore);
				if (queue.size()>k){
					queue.remove();
				}
			}
			Iterator<SimScore> itr = queue.iterator();
			while(itr.hasNext()){
				SimScore simScore = itr.next();
				simMatrix.get(i).put(simScore.id, simScore.score);
			}
		}
	}

	public static void readDataV2(String trainPath) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(trainPath));
			String strLine;
			strLine = in.readLine();
			strLine = in.readLine();
			strLine = in.readLine();
			numJobs = Integer.parseInt(strLine);
			for (int i = 0; i < numTrainUser+numTestUser; i ++) {
				matrix.put(i, new HashSet<Integer>());
			}
			for (int i = 0; i < numTrainUser+numTestUser; i ++) {
				simMatrix.put(i, new HashMap<Integer,Double>());
			}
			
			for(int i=0;i<numTrainUser+numTestUser;i++) {
				strLine = in.readLine();
				String dataLine[]=strLine.split(" ");
				for(int j =0;j<dataLine.length;j++) {
					matrix.get(i).add(Integer.parseInt(dataLine[j]));
				}
			}
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	private static void buildSVMinputCFWords(double[] score, int toPredict) {
		try {
			// Create file
			FileWriter fstream = new FileWriter("SVMinput.txt");
			BufferedWriter out = new BufferedWriter(fstream);
			for (int i = 0; i < score.length; i++) {//users.size()
				if(matrix.get(i).contains(toPredict)){
					out.write("1 ");
				} else {
					out.write("0 ");
				}
				out.write(score[i]+" ");
				HashSet<Integer> words = usersWords.get(i);
				Iterator<Integer> itr = words.iterator();
				while(itr.hasNext()){
					int word = itr.next();
					out.write(word+" ");
				}
				out.newLine();
			}
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static void readUserIdMapping(String UserIDMapping) {
		try {
			BufferedReader in = new BufferedReader(
					new FileReader(UserIDMapping));
			String strLine;
			strLine = in.readLine();
			while (strLine != null) {
				String dataLine[] = strLine.split(" ");
				int data_user_id = Integer.parseInt(dataLine[0]);
				int user_id = Integer.parseInt(dataLine[1]);
				userId.put(data_user_id, user_id);
				usersWords.put(user_id, new HashSet<Integer>());
				strLine = in.readLine();
			}
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static void readData(String trainPath) {

		try {
			BufferedReader in = new BufferedReader(new FileReader(trainPath));
			String strLine;
			strLine = in.readLine();
			int indexTo = 0;
			while (true) {
				strLine = in.readLine();
				String dataLine[] = strLine.split("\t");
				if (!dataLine[1].matches("1")) {
					break;
				}
				if (dataLine.length < 5) {
					continue;
				}
				String dataLine2[] = dataLine[4].split(" ");
				int data_user_id = Integer.parseInt(dataLine[0]);
				if (!userId.containsKey(data_user_id)) {
					continue;
				}
				int user_id = userId.get(data_user_id);
				for (int i = 0; i < dataLine2.length; i++) {
					if (dict.containsKey(dataLine2[i])) {
						int id = dict.get(dataLine2[i]);
						usersWords.get(user_id).add(id);
					} else {
						dict.put(dataLine2[i], indexTo);
						usersWords.get(user_id).add(indexTo);
						indexTo++;
					}
				}
			}
			System.out.println("indexTo: "+indexTo);
			in.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
}
